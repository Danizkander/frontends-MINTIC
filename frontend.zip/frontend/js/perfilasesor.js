fetch('http://129.151.99.197:8081/api/user/all/type/ASE')
    .then(response => response.json())
    .then(data => {
        llenarTarjeta(data.results)
    })

function llenarTarjeta(usuarios) {
    let container = document.querySelector('.container-fluid')
    usuarios.forEach(usuario => {
        container.innerHTML = /*html*/`
        <div class="card">
    <div class="puntos">...</div>
  <div class="card-body" >
    <div class="card-body-item">
    <img src="/images/usuario.png">
<br>
<br>
<div class="texto-medio" >
  <h3 class="nombre" >${usuario.name.first} ${usuario.name.last}</h3>
  <br>
  <br>
  <div class="row">
    <div class="col-6">
      <h4 class="identificaciont" >N° IDENTIFICACIÓN</h4>
      <p class="identificacion" >${usuario.identification}</p>
    </div>
    <br>
    <div class="col-6">
      <h4 class="e-mailt">E- MAIL CORPORATIVO</h4>
      <p class="e-mail">${usuario.email}</p>
    </div>
    <div class="datos">
    <div class="col-8">
      <p>CARGO</p>
      <p>${usuario.type}</p>
    </div>
    <div class="col-lg-6"></div>
    <div class="col-8">
      <p>ZONA</p>
      <p>${usuario.zone}</p>
    </div>
  </div>
  <div class="col-6"></div>
  <div class="col-6"></div>
</div>
</div>

</div>
</div>
  </div>
  </div>

    `
    })

    console.log(usuarios)
}
